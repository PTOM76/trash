chrome.runtime.onMessage.addListener(function(data) {
	if (data.doing == "copy") {
		var keys = {token: ''};
		chrome.storage.local.get(keys, (items) => {
			copyTextToClipboard(items.token);
		});
		return;
	}
	if (data.doing == "check") {
		var keys = {token: ''};
		chrome.storage.local.get(keys, (items) => {
			alert(items.token);
		});
		return;
	}
});
function copyTextToClipboard(text) {
	var copyFrom = document.createElement("textarea");
	copyFrom.textContent = text;
	document.body.appendChild(copyFrom);
	copyFrom.select();
	document.execCommand('copy');
	copyFrom.blur();
	document.body.removeChild(copyFrom);
}