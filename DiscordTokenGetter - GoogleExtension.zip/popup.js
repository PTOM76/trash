$("#copy").on("click", () => {
	chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
		chrome.tabs.sendMessage(tabs[0].id, {
			doing: "copy",
			tab: tabs[0]
		});
	});
});
$("#check").on("click", () => {
	chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
		chrome.tabs.sendMessage(tabs[0].id, {
			doing: "check",
			tab: tabs[0]
		});
	});
});